/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package vu.shapedemo;

/**
 *
 * @author User 1
 */
public class ShapeDemo {

    public static void printAreas(Shape[] shapes) {
        for(Shape shape : shapes) {
            System.out.println(shape.getClass().getSimpleName()
                    + " Area = " + shape.getArea());
        }
    }

    public static Shape largest(Shape[] shapes) {
        Shape largest = shapes[0];
        for(Shape s : shapes) {
            if(s.getArea() > largest.getArea())
                largest = s;
        }
        return largest;
    }

    public static void main(String[] args) {
        try {
            Shape[] shapes = {
                new Circle(5, "Red", true),
                new Rectangle(4, 6, "Blue", true),
                new Triangle(3, 4, 5, "Green", false)
            };

            printAreas(shapes);

            System.out.println("Largest Area Shape: "
                    + largest(shapes).getClass().getSimpleName());

            Triangle bad =
                new Triangle(1, 2, 10, "Black", true);

        } catch (InvalidShapeException e) {
            System.out.println("Exception caught: " + e.getMessage());
        }
    }
}
