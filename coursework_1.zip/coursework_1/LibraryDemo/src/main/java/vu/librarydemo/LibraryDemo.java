/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package vu.librarydemo;

/**
 *
 * @author User 1
 */
public class LibraryDemo {

    public static void main(String[] args) {

        Library library = new Library();

        Book b1 = new Book("001", "Java Programming", "James Gosling");
        Book b2 = new Book("002", "Database Systems", "Elmasri");
        Book b3 = new Book("003", "Web Development", "Jon Duckett");

        Member m1 = new Member("M001", "John");
        Member m2 = new Member("M002", "Sarah");

        library.addBook(b1);
        library.addBook(b2);
        library.addBook(b3);

        library.registerMember(m1);
        library.registerMember(m2);

        System.out.println("===== BEFORE LOANS =====");
        library.displayBooks();

        library.lendBook(b1, m1,
                "10/06/2026", "20/06/2026");

        library.lendBook(b2, m2,
                "11/06/2026", "21/06/2026");

        // Rejected loan
        library.lendBook(b1, m2,
                "12/06/2026", "22/06/2026");

        library.returnBook(b1, m1);

        System.out.println("\n===== AFTER OPERATIONS =====");
        library.displayBooks();
    }
}
