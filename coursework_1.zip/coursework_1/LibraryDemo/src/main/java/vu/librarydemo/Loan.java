/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vu.librarydemo;

/**
 *
 * @author User 1
 */
public class Loan {
    private Member member;
    private Book book;
    private String borrowDate;
    private String dueDate;

    public Loan(Member member, Book book,
                String borrowDate, String dueDate) {
        this.member = member;
        this.book = book;
        this.borrowDate = borrowDate;
        this.dueDate = dueDate;
    }

    public Member getMember() {
        return member;
    }

    public Book getBook() {
        return book;
    }

    public String getBorrowDate() {
        return borrowDate;
    }

    public String getDueDate() {
        return dueDate;
    }

    @Override
    public String toString() {
        return "Loan [Book=" + book.getTitle()
                + ", Member=" + member.getName()
                + ", Borrow Date=" + borrowDate
                + ", Due Date=" + dueDate + "]";
    }
}
