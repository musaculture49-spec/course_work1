/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vu.librarydemo;

/**
 *
 * @author User 1
 */
import java.util.ArrayList;

public class Library {
    private ArrayList<Book> books;
    private ArrayList<Member> members;

    public Library() {
        books = new ArrayList<>();
        members = new ArrayList<>();
    }

    public void addBook(Book book) {
        books.add(book);
    }

    public void registerMember(Member member) {
        members.add(member);
    }

    public void lendBook(Book book, Member member,
                         String borrowDate, String dueDate) {

        if (!book.isAvailable()) {
            System.out.println("Book is already on loan!");
            return;
        }

        Loan loan = new Loan(member, book,
                borrowDate, dueDate);

        member.addLoan(loan);
        book.setAvailable(false);

        System.out.println("Book lent successfully.");
    }

    public void returnBook(Book book, Member member) {

        Loan loanToRemove = null;

        for (Loan loan : member.getLoans()) {
            if (loan.getBook().equals(book)) {
                loanToRemove = loan;
                break;
            }
        }

        if (loanToRemove != null) {
            member.removeLoan(loanToRemove);
            book.setAvailable(true);
            System.out.println("Book returned successfully.");
        }
    }

    public void searchBook(String title) {

        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                System.out.println(book);
                return;
            }
        }

        System.out.println("Book not found.");
    }

    public void displayBooks() {
        for (Book book : books) {
            System.out.println(book);
        }
    }
}
