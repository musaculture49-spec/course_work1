package vu.qn2.exceptions;


public class RiskyDemo {
    
    public static int risky(int n) throws Exception {
        try {
            if (n == 0) {
                throw new Exception("Zero");
            }
            return 100 / n;
        } catch (Exception e) {
            System.out.println("Caught: " + e.getMessage());
            return -1;
        } finally {
            System.out.println("Finally");
        }
    }
    
    public static void main(String[] args) {
        System.out.println("=".repeat(60));
        System.out.println("PART 2b: RISKY METHOD DEMONSTRATION");
        System.out.println("=".repeat(60));
        
        // Test with risky(0)
        System.out.println("\n🔴 Testing risky(0) - throws exception:");
        try {
            int result1 = risky(0);
            System.out.println("risky(0) returned: " + result1);
        } catch (Exception e) {
            System.out.println("Exception propagated to main: " + e.getMessage());
        }
        
        System.out.println("\n" + "-".repeat(40));
        
        // Test with risky(2)
        System.out.println("\n🟢 Testing risky(2) - successful:");
        try {
            int result2 = risky(2);
            System.out.println("risky(2) returned: " + result2);
        } catch (Exception e) {
            System.out.println("Exception propagated: " + e.getMessage());
        }
        
        System.out.println("\n📝 EXPLANATION:");
        System.out.println("• risky(0): Exception thrown → caught → returns -1");
        System.out.println("• risky(2): No exception → returns 50");
        System.out.println("• Finally block ALWAYS executes in both cases");
    }
}