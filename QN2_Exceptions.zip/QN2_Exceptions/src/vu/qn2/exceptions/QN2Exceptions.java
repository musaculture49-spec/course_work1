package vu.qn2.exceptions;

/**
 * Main demonstration class for all parts of Question 2
 * This combines all parts into one complete demo
 */
public class QN2Exceptions {
    
    public static void main(String[] args) {
        System.out.println("=".repeat(70));
        System.out.println("QUESTION 2: EXCEPTIONS AND RESOURCE HANDLING");
        System.out.println("=".repeat(70));
        
        // PART 2a: Finally Block
        System.out.println("\n" + "=".repeat(70));
        System.out.println("PART 2a: FINALLY BLOCK WITH RETURN");
        System.out.println("=".repeat(70));
        demoPart2a();
        
        // PART 2b: Risky Method
        System.out.println("\n" + "=".repeat(70));
        System.out.println("PART 2b: RISKY METHOD WITH TRY-CATCH-FINALLY");
        System.out.println("=".repeat(70));
        demoPart2b();
        
        // PART 2c: Checked vs Unchecked Exceptions
        System.out.println("\n" + "=".repeat(70));
        CheckedVsUncheckedDemo.main(new String[]{});
        
        // PART 2d: Try-With-Resources
        System.out.println("\n" + "=".repeat(70));
        System.out.println("PART 2d: TRY-WITH-RESOURCES");
        System.out.println("=".repeat(70));
        demoPart2d();
        
        System.out.println("\n" + "=".repeat(70));
        System.out.println("✅ ALL PARTS COMPLETED SUCCESSFULLY");
        System.out.println("=".repeat(70));
    }
    
    /**
     * Demo for Part 2a: Finally Block
     */
    private static void demoPart2a() {
        System.out.println("\nCalling testFinally():");
        int result = FinallyDemo.testFinally();
        System.out.println("Result returned to caller: " + result);
        
        System.out.println("\n📝 EXPLANATION:");
        System.out.println("  When finally block has a return statement,");
        System.out.println("  it OVERRIDES the return value from the try block.");
        System.out.println("  Therefore, 20 is returned instead of 10.");
    }
    
    /**
     * Demo for Part 2b: Risky Method
     */
    private static void demoPart2b() {
        System.out.println("\n🔴 Testing risky(0) (throws exception):");
        try {
            int result1 = RiskyDemo.risky(0);
            System.out.println("Result: " + result1);
        } catch (Exception e) {
            System.out.println("Exception propagated: " + e.getMessage());
        }
        
        System.out.println("\n🟢 Testing risky(2) (successful):");
        try {
            int result2 = RiskyDemo.risky(2);
            System.out.println("Result: " + result2);
        } catch (Exception e) {
            System.out.println("Exception propagated: " + e.getMessage());
        }
        
        System.out.println("\n📝 EXPLANATION:");
        System.out.println("  risky(0): Exception thrown → caught → returns -1");
        System.out.println("  risky(2): No exception → returns 50");
        System.out.println("  Finally block ALWAYS executes in both cases");
    }
    
    /**
     * Demo for Part 2d: Try-With-Resources
     */
    private static void demoPart2d() {
        // Create sample file
        FileResourceHandler.createSampleFile();
        
        // Show problematic code
        FileResourceHandler.problematicCode();
        
        // Show corrected code with try-with-resources
        FileResourceHandler.tryWithResourcesExample();
        
        // Show advantages
        System.out.println("\n📝 ADVANTAGES OF TRY-WITH-RESOURCES:");
        System.out.println("  1. Automatic resource closing");
        System.out.println("  2. Cleaner code (no nested finally)");
        System.out.println("  3. Prevents resource leaks");
        System.out.println("  4. Resources closed in reverse order");
        System.out.println("  5. Works with any AutoCloseable resource");
    }
}