package vu.qn2.exceptions;

/**
 * Part 2c: Demonstrates difference between checked and unchecked exceptions
 */
public class CheckedVsUncheckedDemo {
    
    public static void main(String[] args) {
        System.out.println("=".repeat(60));
        System.out.println("PART 2c: CHECKED vs UNCHECKED EXCEPTIONS");
        System.out.println("=".repeat(60));
        
        PaymentSystem payment = new PaymentSystem("ACC001", 5000.0, "UGX");
        System.out.println("\nAccount created: " + payment);
        
        // 1️⃣ CHECKED EXCEPTION - MUST be handled
        System.out.println("\n" + "─".repeat(40));
        System.out.println("1️⃣ CHECKED EXCEPTION (Must be handled by compiler)");
        System.out.println("─".repeat(40));
        
        try {
            payment.withdraw(7000.0);  // Exceeds balance - throws checked exception
            System.out.println("This line won't execute");
        } catch (InsufficientFundsException e) {
            System.out.println("\n✅ Exception HANDLED (Required by compiler)");
            System.out.println("   Details: " + e);
            System.out.println("   💡 Suggestion: Try a smaller amount or deposit more funds.");
        }
        
        // 2️⃣ UNCHECKED EXCEPTION - NOT required to be handled
        System.out.println("\n" + "─".repeat(40));
        System.out.println("2️⃣ UNCHECKED EXCEPTION (Optional to handle)");
        System.out.println("─".repeat(40));
        
        try {
            payment.deposit(-100.0);  // Negative amount - throws unchecked exception
            System.out.println("This line won't execute");
        } catch (IllegalArgumentException e) {
            System.out.println("\n✅ Exception HANDLED (Optional - not required)");
            System.out.println("   Details: " + e.getMessage());
        }
        
        // 3️⃣ UNCHECKED EXCEPTION - Programming error
        System.out.println("\n" + "─".repeat(40));
        System.out.println("3️⃣ UNCHECKED EXCEPTION (Programming Error)");
        System.out.println("─".repeat(40));
        
        try {
            String str = null;
            str.length();  // NullPointerException - unchecked
        } catch (NullPointerException e) {
            System.out.println("\n✅ Caught: " + e);
            System.out.println("   💡 This indicates a programming error that should be fixed.");
        }
        
        // COMPARISON SUMMARY
        System.out.println("\n" + "=".repeat(60));
        System.out.println("📊 COMPARISON SUMMARY");
        System.out.println("=".repeat(60));
        
        System.out.println("\n┌─────────────────────────────────────────────────────┐");
        System.out.println("│            ✅ CHECKED EXCEPTIONS                   │");
        System.out.println("├─────────────────────────────────────────────────────┤");
        System.out.println("│ • MUST be caught or declared (throws)            │");
        System.out.println("│ • Extends Exception (not RuntimeException)       │");
        System.out.println("│ • Compile-time checking is ENFORCED              │");
        System.out.println("│ • Example: InsufficientFundsException            │");
        System.out.println("│ • Used for recoverable conditions               │");
        System.out.println("│ • Forces programmer to handle errors            │");
        System.out.println("├─────────────────────────────────────────────────────┤");
        System.out.println("│            ⚠️ UNCHECKED EXCEPTIONS               │");
        System.out.println("├─────────────────────────────────────────────────────┤");
        System.out.println("│ • NOT required to be caught or declared          │");
        System.out.println("│ • Extends RuntimeException                       │");
        System.out.println("│ • Runtime checking only (optional)              │");
        System.out.println("│ • Example: NullPointerException,                 │");
        System.out.println("│   IllegalArgumentException                       │");
        System.out.println("│ • Used for programming errors                   │");
        System.out.println("│ • Often indicates bugs in code                 │");
        System.out.println("└─────────────────────────────────────────────────────┘");
    }
}