package vu.qn2.exceptions;

/**
 * Payment system using checked exception
 */
public class PaymentSystem {
    private String accountId;
    private double balance;
    private String currency;
    
    public PaymentSystem(String accountId, double initialBalance, String currency) {
        this.accountId = accountId;
        this.balance = initialBalance;
        this.currency = currency;
    }
    
    /**
     * Withdraw method - throws checked InsufficientFundsException
     * MUST be caught or declared with 'throws'
     */
    public void withdraw(double amount) throws InsufficientFundsException {
        System.out.println("\n=== WITHDRAWAL REQUEST ===");
        System.out.println("Account: " + accountId);
        System.out.println("Amount requested: " + currency + " " + amount);
        System.out.println("Current balance: " + currency + " " + balance);
        
        if (amount <= 0) {
            throw new IllegalArgumentException("Withdrawal amount must be positive");
        }
        
        if (amount > balance) {
            double deficit = amount - balance;
            
            // This is a CHECKED exception - compiler forces us to handle it
            InsufficientFundsException ex = new InsufficientFundsException(
                "Insufficient funds for withdrawal",
                amount,
                balance,
                "WITHDRAWAL"
            );
            
            System.out.println("❌ ERROR: " + ex.getMessage());
            System.out.println("   Deficit: " + currency + " " + deficit);
            System.out.println("   Transaction type: " + ex.getTransactionType());
            
            throw ex;  // Throwing checked exception
        }
        
        balance -= amount;
        System.out.println("✅ Withdrawal successful!");
        System.out.println("   New balance: " + currency + " " + balance);
    }
    
    public void deposit(double amount) {
        System.out.println("\n=== DEPOSIT REQUEST ===");
        System.out.println("Amount to deposit: " + currency + " " + amount);
        
        if (amount <= 0) {
            // This is an UNCHECKED exception - compiler doesn't force handling
            throw new IllegalArgumentException("Deposit amount must be positive");
        }
        
        balance += amount;
        System.out.println("✅ Deposit successful!");
        System.out.println("   New balance: " + currency + " " + balance);
    }
    
    public double getBalance() {
        return balance;
    }
    
    public String getAccountId() {
        return accountId;
    }
    
    @Override
    public String toString() {
        return "PaymentSystem{" +
               "accountId='" + accountId + '\'' +
               ", balance=" + balance +
               ", currency='" + currency + '\'' +
               '}';
    }
}