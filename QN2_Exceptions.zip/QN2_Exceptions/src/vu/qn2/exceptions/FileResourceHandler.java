package vu.qn2.exceptions;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Part 2d: Demonstrates try-with-resources for proper resource handling
 */
public class FileResourceHandler {
    
    /**
     * Creates a sample data file for testing
     */
    public static void createSampleFile() {
        System.out.println("\n--- Creating Sample File ---");
        try (FileWriter writer = new FileWriter("data.txt")) {
            writer.write("Line 1: First line\n");
            writer.write("Line 2: Second line\n");
            writer.write("Line 3: Third line\n");
            writer.write("Line 4: Fourth line\n");
            writer.write("Line 5: Fifth line\n");
            System.out.println("✅ data.txt created successfully.");
        } catch (IOException e) {
            System.err.println("❌ Error creating file: " + e.getMessage());
        }
    }
    
    /**
     * PROBLEMATIC CODE - Leaks file handle if exception occurs
     * This is the code that needs to be fixed
     */
    public static void problematicCode() {
        System.out.println("\n" + "─".repeat(40));
        System.out.println("⚠️ PROBLEMATIC CODE (Leaks Resource)");
        System.out.println("─".repeat(40));
        System.out.println("If an exception occurs before close(), the file handle LEAKS!");
        
        try {
            // If exception occurs before close(), resource leaks!
            BufferedReader reader = new BufferedReader(new FileReader("data.txt"));
            String line = reader.readLine();
            System.out.println("Read: " + line);
            reader.close(); // May NOT execute if exception occurs
        } catch (IOException e) {
            System.err.println("❌ Error: " + e.getMessage());
        }
    }
    
    /**
     * SOLUTION: Try-with-resources automatically closes resources
     * This is the CORRECTED version
     */
    public static void tryWithResourcesExample() {
        System.out.println("\n" + "─".repeat(40));
        System.out.println("✅ SOLUTION: Try-With-Resources");
        System.out.println("─".repeat(40));
        System.out.println("Resources are AUTOMATICALLY closed!");
        
        try (BufferedReader reader = new BufferedReader(new FileReader("data.txt"))) {
            String line;
            int lineNumber = 0;
            
            System.out.println("Reading file contents:");
            while ((line = reader.readLine()) != null) {
                lineNumber++;
                System.out.println("Line " + lineNumber + ": " + line);
            }
            System.out.println("\n✅ Total lines read: " + lineNumber);
            
        } catch (IOException e) {
            System.err.println("❌ Error reading file: " + e.getMessage());
        }
        // No explicit close() needed - AUTOMATICALLY CLOSED!
    }
    
    public static void main(String[] args) {
        System.out.println("=".repeat(60));
        System.out.println("PART 2d: TRY-WITH-RESOURCES DEMONSTRATION");
        System.out.println("=".repeat(60));
        
        // Create sample file
        createSampleFile();
        
        // Show problematic code
        problematicCode();
        
        // Show corrected code with try-with-resources
        tryWithResourcesExample();
        
        // Show advantages
        System.out.println("\n" + "=".repeat(60));
        System.out.println("📝 ADVANTAGES OF TRY-WITH-RESOURCES");
        System.out.println("=".repeat(60));
        System.out.println("  1. ✅ Automatic resource closing (even with exceptions)");
        System.out.println("  2. ✅ Cleaner code - no nested try-catch-finally");
        System.out.println("  3. ✅ Resources closed in reverse order of creation");
        System.out.println("  4. ✅ Prevents resource leaks");
        System.out.println("  5. ✅ Works with any class implementing AutoCloseable");
        System.out.println("  6. ✅ Suppressed exceptions are collected");
        System.out.println("  7. ✅ Reduces boilerplate code");
    }
}