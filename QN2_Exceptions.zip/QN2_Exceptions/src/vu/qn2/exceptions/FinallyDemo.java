package vu.qn2.exceptions;


public class FinallyDemo {
    
    public static int testFinally() {
        try {
            return 10;
        } finally {
            System.out.println("Finally block executed");
            return 20;
        }
    }
    
    public static void main(String[] args) {
        System.out.println("=".repeat(60));
        System.out.println("PART 2a: FINALLY BLOCK DEMONSTRATION");
        System.out.println("=".repeat(60));
        
        int result = testFinally();
        System.out.println("\nValue returned to caller: " + result);
        
        System.out.println("\n📝 EXPLANATION:");
        System.out.println("• The finally block ALWAYS executes");
        System.out.println("• When finally has a return statement, it OVERRIDES");
        System.out.println("  the return value from the try block");
        System.out.println("• Therefore, 20 is returned instead of 10");
    }
}