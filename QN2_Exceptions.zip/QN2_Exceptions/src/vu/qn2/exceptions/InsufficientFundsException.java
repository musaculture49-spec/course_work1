package vu.qn2.exceptions;

/**
 * Part 2c: Custom checked exception for insufficient funds
 * Extends Exception (checked) not RuntimeException (unchecked)
 */
public class InsufficientFundsException extends Exception {
    private double requestedAmount;
    private double currentBalance;
    private String transactionType;
    
    // Constructor 1: Basic message only
    public InsufficientFundsException(String message) {
        super(message);
        this.requestedAmount = 0;
        this.currentBalance = 0;
        this.transactionType = "UNKNOWN";
    }
    
    // Constructor 2: Full details (FIXED - includes requestedAmount)
    public InsufficientFundsException(String message, double requestedAmount, 
                                     double currentBalance, String transactionType) {
        super(message);
        this.requestedAmount = requestedAmount;  // ← THIS WAS MISSING BEFORE
        this.currentBalance = currentBalance;
        this.transactionType = transactionType;
    }
    
    // Constructor 3: Simplified version
    public InsufficientFundsException(String message, double requestedAmount, 
                                     double currentBalance) {
        super(message);
        this.requestedAmount = requestedAmount;
        this.currentBalance = currentBalance;
        this.transactionType = "WITHDRAWAL";
    }
    
    // Getters
    public double getRequestedAmount() {
        return requestedAmount;
    }
    
    public double getCurrentBalance() {
        return currentBalance;
    }
    
    public String getTransactionType() {
        return transactionType;
    }
    
    public double getDeficit() {
        return requestedAmount - currentBalance;
    }
    
    public double getAmount() {
        return requestedAmount;
    }
    
    @Override
    public String toString() {
        return "InsufficientFundsException{" +
               "message='" + getMessage() + '\'' +
               ", requestedAmount=" + requestedAmount +
               ", currentBalance=" + currentBalance +
               ", deficit=" + getDeficit() +
               ", type='" + transactionType + '\'' +
               '}';
    }
}