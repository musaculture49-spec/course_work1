package vu.qn3.aquasmart.meter;

public class Main {

    public static void main(String[] args) {

        SmartMeter meter = new SmartMeter("M001", 500);

        System.out.println("Initial Credit: " + meter.getCreditBalance());

        meter.recordConsumption(4);

        System.out.println("Credit After Consumption: " + meter.getCreditBalance());

        meter.loadToken(300);

        System.out.println("Credit After Loading Token: " + meter.getCreditBalance());

        System.out.println("Valve Open: " + meter.isValveOpen());
    }
}