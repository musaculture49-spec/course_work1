package vu.qn3.aquasmart.meter;

public class SmartMeterTest {

    public static void main(String[] args) {

        SmartMeter meter = new SmartMeter("M002", 100);

        meter.recordConsumption(5);

        if (!meter.isValveOpen()) {
            System.out.println("Test 1 Passed");
        } else {
            System.out.println("Test 1 Failed");
        }

        meter.loadToken(500);

        if (meter.isValveOpen()) {
            System.out.println("Test 2 Passed");
        } else {
            System.out.println("Test 2 Failed");
        }
    }
}