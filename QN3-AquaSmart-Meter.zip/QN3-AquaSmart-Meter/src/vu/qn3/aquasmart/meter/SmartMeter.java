package vu.qn3.aquasmart.meter;

public class SmartMeter {

    private String meterId;
    private double creditBalance;
    private boolean valveOpen;

    public SmartMeter(String meterId, double creditBalance) {
        this.meterId = meterId;
        this.creditBalance = creditBalance;
        this.valveOpen = true;
    }

    public double loadToken(double amount) {
        creditBalance += amount;
        valveOpen = true;
        return creditBalance;
    }

    public boolean recordConsumption(double litres) {

        double cost = litres * 50;

        if (!valveOpen || creditBalance <= 0) {
            return false;
        }

        creditBalance -= cost;

        if (creditBalance <= 0) {
            creditBalance = 0;
            valveOpen = false;
        }

        return true;
    }

    public String getMeterId() {
        return meterId;
    }

    public double getCreditBalance() {
        return creditBalance;
    }

    public boolean isValveOpen() {
        return valveOpen;
    }
}