package vu.qn1.accounts.uml;

/**
 * CurrentAccount - extends Account
 * Features: Overdraft facility, can go negative up to overdraft limit
 */
public class CurrentAccount extends Account {
    private double overdraftLimit;
    
    /**
     * Constructor for CurrentAccount
     * @param accountNumber Account identifier
     * @param balance Initial balance
     * @param overdraftLimit Maximum negative balance allowed
     */
    public CurrentAccount(String accountNumber, double balance, double overdraftLimit) {
        super(accountNumber, balance);
        this.overdraftLimit = overdraftLimit;
    }
    
    /**
     * Withdraw method - allows balance to go negative up to overdraft limit
     * @param amount The amount to withdraw
     * @return true if withdrawal successful, false if exceeds overdraft limit
     */
    @Override
    public boolean withdraw(double amount) {
        if (amount > 0 && (balance - amount) >= -overdraftLimit) {
            balance -= amount;
            System.out.println("Withdrawn: " + amount + ", New Balance: " + balance);
            if (balance < 0) {
                System.out.println("Warning: Account is overdrawn by " + Math.abs(balance));
            }
            return true;
        } else if (amount <= 0) {
            System.out.println("Invalid withdrawal amount: " + amount);
            return false;
        } else {
            System.out.println("Withdrawal denied: Exceeds overdraft limit. " +
                             "Balance: " + balance + ", Overdraft Limit: " + overdraftLimit +
                             ", Requested: " + amount);
            return false;
        }
    }
    
    public double getOverdraftLimit() {
        return overdraftLimit;
    }
    
    public void setOverdraftLimit(double overdraftLimit) {
        if (overdraftLimit >= 0) {
            this.overdraftLimit = overdraftLimit;
        }
    }
    
    @Override
    public String toString() {
        return "CurrentAccount{" +
               "accountNumber='" + accountNumber + '\'' +
               ", balance=" + balance +
               ", overdraftLimit=" + overdraftLimit +
               '}';
    }
}