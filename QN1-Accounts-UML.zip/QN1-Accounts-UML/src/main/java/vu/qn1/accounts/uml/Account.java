package vu.qn1.accounts.uml;

/**
 * Abstract Account class implementing Statement interface
 * Represents a bank account with basic operations
 */
public abstract class Account implements Statement {
    // Protected attributes as per UML
    protected String accountNumber;
    protected double balance;
    
    /**
     * Constructor for Account
     * @param accountNumber The account identifier
     * @param balance The initial balance
     */
    public Account(String accountNumber, double balance) {
        this.accountNumber = accountNumber;
        this.balance = balance;
    }
    
    /**
     * Gets the account number
     * @return The account number
     */
    public String getAccountNumber() {
        return accountNumber;
    }
    
    /**
     * Gets the current balance
     * @return The current balance
     */
    public double getBalance() {
        return balance;
    }
    
    /**
     * Deposits money into the account
     * @param amount The amount to deposit (must be positive)
     */
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited: " + amount + ", New Balance: " + balance);
        } else {
            System.out.println("Invalid deposit amount. Amount must be positive.");
        }
    }
    
    /**
     * Abstract withdraw method - to be implemented by subclasses
     * @param amount The amount to withdraw
     * @return true if withdrawal was successful, false otherwise
     */
    public abstract boolean withdraw(double amount);
    
    /**
     * Implements generateStatement from Statement interface
     * @return A formatted statement string
     */
    @Override
    public String generateStatement() {
        return "Account Number: " + accountNumber + 
               "\nCurrent Balance: UGX " + String.format("%.2f", balance);
    }
    
    @Override
    public String toString() {
        return "Account{" +
               "accountNumber='" + accountNumber + '\'' +
               ", balance=" + balance +
               '}';
    }
}