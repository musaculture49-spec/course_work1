package vu.qn1.accounts.uml;

/**
 * Statement interface - defines the contract for generating account statements
 */
public interface Statement {
    /**
     * Generates a statement for the account
     * @return String representation of the account statement
     */
    String generateStatement();
}