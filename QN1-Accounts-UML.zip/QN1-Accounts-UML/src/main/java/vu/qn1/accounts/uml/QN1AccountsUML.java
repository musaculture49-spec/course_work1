package vu.qn1.accounts.uml;

/**
 * Main class to test the Accounts UML implementation
 */
public class QN1AccountsUML {
    
    public static void main(String[] args) {
        System.out.println("=== ACCOUNTS UML IMPLEMENTATION TEST ===\n");
        
        // Create customers
        Customer customer1 = new Customer("C001", "John Mukasa");
        Customer customer2 = new Customer("C002", "Sarah Nakato");
        
        // Create savings account
        SavingsAccount savings = new SavingsAccount("SAV001", 1000000, 5.0);
        customer1.addAccount(savings);
        
        // Create current account with overdraft
        CurrentAccount current = new CurrentAccount("CUR001", 500000, 200000);
        customer1.addAccount(current);
        
        // Create another savings account for second customer
        SavingsAccount savings2 = new SavingsAccount("SAV002", 2000000, 4.5);
        customer2.addAccount(savings2);
        
        // Test operations on savings account
        System.out.println("\n=== SAVINGS ACCOUNT OPERATIONS ===");
        System.out.println(savings.generateStatement());
        savings.deposit(200000);
        savings.withdraw(300000);  // Should succeed
        savings.withdraw(1000000); // Should fail (insufficient)
        savings.addInterest();
        System.out.println("Updated balance: " + savings.getBalance());
        
        // Test operations on current account
        System.out.println("\n=== CURRENT ACCOUNT OPERATIONS ===");
        System.out.println(current.generateStatement());
        current.deposit(100000);
        current.withdraw(300000);  // Should succeed
        current.withdraw(400000);  // Should succeed (using overdraft)
        current.withdraw(300000);  // Should fail (exceeds overdraft)
        System.out.println("Updated balance: " + current.getBalance());
        
        // Test customer total worth
        System.out.println("\n=== CUSTOMER TOTAL WORTH ===");
        System.out.println(customer1);
        System.out.println("Customer: " + customer1.getName());
        System.out.println("Total Worth: UGX " + String.format("%.2f", customer1.totalWorth()));
        
        System.out.println("\n" + customer2);
        System.out.println("Customer: " + customer2.getName());
        System.out.println("Total Worth: UGX " + String.format("%.2f", customer2.totalWorth()));
        
        // Generate statements
        System.out.println("\n=== ACCOUNT STATEMENTS ===");
        for (Account acc : customer1.getAccounts()) {
            System.out.println("---");
            System.out.println(acc.generateStatement());
            System.out.println("Type: " + acc.getClass().getSimpleName());
        }
        
        System.out.println("\n=== TEST COMPLETE ===");
    }
}