package vu.qn1.accounts.uml;

import java.util.ArrayList;
import java.util.List;

/**
 * Customer class - manages multiple accounts
 * Aggregation relationship with Account (one Customer can have many Accounts)
 */
public class Customer {
    private String customerId;
    private String name;
    private List<Account> accounts;
    
    /**
     * Constructor for Customer
     * @param customerId Unique customer identifier
     * @param name Customer's full name
     */
    public Customer(String customerId, String name) {
        this.customerId = customerId;
        this.name = name;
        this.accounts = new ArrayList<>();
    }
    
    public String getCustomerId() {
        return customerId;
    }
    
    public String getName() {
        return name;
    }
    
    /**
     * Adds an account to the customer's collection
     * @param account The account to add
     */
    public void addAccount(Account account) {
        if (account != null) {
            accounts.add(account);
            System.out.println("Account " + account.getAccountNumber() + 
                             " added to customer " + name);
        }
    }
    
    /**
     * Removes an account from the customer's collection
     * @param accountNumber The account number to remove
     * @return true if removed, false if not found
     */
    public boolean removeAccount(String accountNumber) {
        for (Account account : accounts) {
            if (account.getAccountNumber().equals(accountNumber)) {
                accounts.remove(account);
                System.out.println("Account " + accountNumber + " removed");
                return true;
            }
        }
        System.out.println("Account " + accountNumber + " not found");
        return false;
    }
    
    /**
     * Gets all accounts for this customer
     * @return A copy of the accounts list (defensive copy)
     */
    public List<Account> getAccounts() {
        return new ArrayList<>(accounts);
    }
    
    /**
     * Calculates the total worth of all accounts
     * @return Sum of all account balances
     */
    public double totalWorth() {
        double total = 0;
        for (Account account : accounts) {
            total += account.getBalance();
        }
        return total;
    }
    
    /**
     * Finds an account by account number
     * @param accountNumber The account number to find
     * @return The Account object or null if not found
     */
    public Account findAccount(String accountNumber) {
        for (Account account : accounts) {
            if (account.getAccountNumber().equals(accountNumber)) {
                return account;
            }
        }
        return null;
    }
    
    @Override
    public String toString() {
        return "Customer{" +
               "customerId='" + customerId + '\'' +
               ", name='" + name + '\'' +
               ", numberOfAccounts=" + accounts.size() +
               ", totalWorth=" + totalWorth() +
               '}';
    }
}