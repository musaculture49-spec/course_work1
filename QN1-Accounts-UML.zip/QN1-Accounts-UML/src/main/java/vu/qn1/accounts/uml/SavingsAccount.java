package vu.qn1.accounts.uml;

/**
 * SavingsAccount - extends Account
 * Features: No negative balance allowed, interest accumulation
 */
public class SavingsAccount extends Account {
    private double interestRate;
    
    /**
     * Constructor for SavingsAccount
     * @param accountNumber Account identifier
     * @param balance Initial balance
     * @param interestRate Annual interest rate in percentage
     */
    public SavingsAccount(String accountNumber, double balance, double interestRate) {
        super(accountNumber, balance);
        this.interestRate = interestRate;
    }
    
    /**
     * Withdraw method - refuses any withdrawal that would make balance negative
     * @param amount The amount to withdraw
     * @return true if withdrawal successful, false if insufficient funds
     */
    @Override
    public boolean withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("Withdrawn: " + amount + ", New Balance: " + balance);
            return true;
        } else if (amount > balance) {
            System.out.println("Withdrawal denied: Insufficient funds. " +
                             "Balance: " + balance + ", Requested: " + amount);
            return false;
        } else {
            System.out.println("Invalid withdrawal amount: " + amount);
            return false;
        }
    }
    
    /**
     * Adds interest to the balance
     * Calculates interest as: balance * (interestRate / 100)
     */
    public void addInterest() {
        if (balance > 0) {
            double interest = balance * (interestRate / 100);
            balance += interest;
            System.out.println("Interest added: " + interest + 
                             " (Rate: " + interestRate + "%), New Balance: " + balance);
        } else {
            System.out.println("No interest added - balance is zero or negative");
        }
    }
    
    public double getInterestRate() {
        return interestRate;
    }
    
    public void setInterestRate(double interestRate) {
        if (interestRate >= 0) {
            this.interestRate = interestRate;
        }
    }
    
    @Override
    public String toString() {
        return "SavingsAccount{" +
               "accountNumber='" + accountNumber + '\'' +
               ", balance=" + balance +
               ", interestRate=" + interestRate +
               '}';
    }
}